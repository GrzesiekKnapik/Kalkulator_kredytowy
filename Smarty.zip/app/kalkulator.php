
<?php
require_once dirname(__FILE__).'/../config.php';


//kontroler



//gdy jeszcze nie podalismy liczby nie wyswietla sie nic, gdy 
//podamy wyswietla sie ciągle liczba nawet po podaniu wyniku, dlatego tak

function getParams(&$kwota,&$oprocentowanie,&$czas){
	$kwota= isset($_REQUEST['kwota']) ? $_REQUEST['kwota'] : null;
	$oprocentowanie = isset($_REQUEST['oprocentowanie']) ? $_REQUEST['oprocentowanie'] : null;
	$czas= isset($_REQUEST['czas']) ? $_REQUEST['czas'] : 24;
}


/* ///usunac
$kwota = $_REQUEST["kwota"];
$oprocentowanie = ($_REQUEST["oprocentowanie"]);
$czas = $_REQUEST["czas"];

if ($kwota == "" || $oprocentowanie==""){
	$messages = 1;
}else if($kwota == "0" || $oprocentowanie=="0"){
	$messages = 2;

}else 
{
$rata = $kwota/$czas + $kwota/$czas*$oprocentowanie/100;
$rata = round($rata,2);
}
*/

function validate(&$kwota,&$oprocentowanie,&$czas,&$messages){
	// jeżeli parametry zostaly poprawnie podane to zwraca falsz i idziemy dalej
	//chodzi o podanie parametrow przed wyswietleniem okna gdzie sie wpisuje dlatego !
	// dzieki request to chyba nie jest do konca potrzebne
	if (! (isset($kwota) && isset($oprocentowanie) && isset($czas))) {

		return false;
	}

	// typowa walidacja
	if ($kwota == "") {
		$messages [] = 'Nie podano kwoty kredytu!';
	}
	if ($oprocentowanie == "") {
		$messages [] = 'Nie podano wysokości oprocentowania!';
	}

	//gdy nie podamy parametrów to juz koniec sprawdzania
	if (count ( $messages ) != 0) 
		return false;
	
	// sprawdzenie, czy wpisane dane są na pewno liczbami a nie literami...
	if (! is_numeric( $kwota )) {
		$messages [] = 'Podana wartość w kwocie kredytu nie jest liczbą!';
	}
	
	if (! is_numeric( $oprocentowanie )) {
		$messages [] = 'Podana wartość w wysokości oprocentowania nie jest liczbą!';
	}	
	
	if (count ( $messages ) != 0) 
		return false;
	else return true;
}

function obliczenia(&$kwota,&$oprocentowanie,&$czas,&$messages,&$rata){
	
	$rata = $kwota/$czas + $kwota/$czas*$oprocentowanie/100;
$rata = round($rata,2);
	
	
}



//definicja zmiennych kontrolera
$kwota = null;
$oprocentowanie = null;
$czas = null;
$rata = null;
$messages = array();

//pobierz parametry i wykonaj zadanie jeśli wszystko w porządku
getParams($kwota,$oprocentowanie,$czas);
if ( validate($kwota,$oprocentowanie,$czas,$messages) ) { // gdy brak błędów
	obliczenia($kwota,$oprocentowanie,$czas,$messages,$rata);
}





include 'kalkulator_widok.php';
