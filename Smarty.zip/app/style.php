<?php
header('content-type: text/css; charset:UTF-8')
?>


.tlo{
	
	background-image: url("rr.jpg");
	position:absolute;
	height:100%;
	width:100%
	
}

.styl_prawy_górny{
	width:95%;
	margin: 3em auto;
	text-align:right;
	
}


.styl_główny{
	width:50%;
	margin: 1em auto;
	text-align: center;
	
}

.wynik{
	margin-left: auto;
	margin-right:auto;
	margin-top: 20px;
	padding: 10px;
	border-radius: 5px;
	background-color: #04AA6D;
	width:300px;
	
}

.błędy{
	margin-left: auto;
	margin-right:auto;
	margin-top: 1em;
	padding: 1em 1em 1em 2em;
	border-radius: 1em;
	background-color: #f88;
	width:25em;
}