
<!DOCTYPE HTML>
<html lang = "pl">



<head>
	<title>Kalkulator kredytowy</title>
	<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
	<link rel="stylesheet" href="style.php" type="text/css">
</head>





<body>

<div class="tlo">

<div class="styl_prawy_górny">
	<a href="<?php print(_APP_ROOT); ?>/app/inna_chroniona.php" class="pure-button">kolejna chroniona strona</a>
	<a href="<?php print(_APP_ROOT); ?>/app/security/logout.php" class="pure-button"; style="background-color:rgb(202, 60, 60)";>Wyloguj</a>
</div>


<div class="styl_główny">


	

	
	<h1>Kalkulator kredytowy - oblicznie miesięcznej raty</h1>
	
	<form action="<?php print(_APP_URL);?>/app/kalkulator.php" method="post">
	
	<!--kwota to nasza zmienna-->
	Kwota kredytu <br>   
	<input type="text" name ="kwota" 
	value="<?php 
	 print($kwota);?>" />PLN
	
	
	<br><br>
	<!--value jest potrzebne do zapisania -->
	Okres spłaty <br>
	<input type="range" min="3" max="48" name="czas" 
	value="<?php print($czas) ?>";
    oninput="nextElementSibling.value = value"/>
	<output><?php 
		print($czas)
	?></output> miesiące
		
	
	
	
	<br><br>
	Wysokość oprocentowania <br>
	<input type="text" name ="oprocentowanie" 
	value="<?php 
		print($oprocentowanie);
	?>"/>%
	
	<br><br>
	
	<input type="submit" value="Oblicz" class="pure-button"/> 
	</form>

<!--///usunac	

<?php
if (isset($messages)) { ?>
<div style="margin-left: auto;margin-right:auto; margin-top: 20px; padding: 10px; border-radius: 5px; background-color: #fc2803; width:300px;">
<?php if($messages==1) echo 'Błąd: brak danych';
if($messages==2) echo 'Błąd: podano wartość 0';
?>
</div>
<?php } ?>

-->



<?php
//wyświeltenie listy błędów, jeśli istnieją
if (isset($messages)) {
	if (count ( $messages ) > 0) {
		echo '<ol class="błędy">';
		foreach ( $messages as $key => $msg ) {
			echo '<li>'.$msg.'</li>';
		}
		echo '</ol>';
	}
}
?>

	
	
<?php if (isset($rata)) { ?>
<div class="wynik">
<?php echo 'Wynik: '.$rata; ?>
</div>
<?php } ?>	








</div>
</div>
</div>

</body>

</html>

