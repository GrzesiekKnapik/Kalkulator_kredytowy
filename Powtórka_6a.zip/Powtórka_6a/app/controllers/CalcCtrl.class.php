<?php
// W skrypcie definicji kontrolera nie trzeba dołączać problematycznego skryptu config.php, 
            
// Konfiguracja, Messages i Smarty są dostępne za pomocą odpowiednich funkcji.
// Kontroler ładuje tylko to z czego sam korzysta.


require_once 'CalcTab.class.php';
require_once 'CalcResult.class.php';





		//jest są to obiekty reprezentujące dane 
                //obiekt prywatny tab reprezentuje dane formularza czyli kwota, oprocentowanie, czas
    
                class CalcCtrl
                {
                   
                    private $tab;
                    private $result;
                
                   
                    //__construct mozna zwykłą nazwą dać i wywolac w equals, tak to nie trzeba wywoływać
                    public function __construct()
                    {
                        //na tym tabie tworze obiekt ^^
                        //this->tab->kwota == tab.kwota
                        $this->tab = new CalcTab();
                        $this->result = new CalcResult();
                       
                        
                        
                    }
                    
                    
                    
                    
                    


                    public function getParams()
			{
				$this->tab->kwota = getFromRequest('kwota');
				$this->tab->czas = getFromRequest('czas');
				$this->tab->oprocentowanie = getFromRequest('oprocentowanie');
			}
                        
                        
                    
                    
                    
                    
                    public function validate()
		{
			//isset respektuje null
			//czemu isset raz jest ustawiony a raz nie
			//!!po co to jest? daje to tylko to ze nie wyswietla sie po starcie messages brak kwoty... i dlaczego tak dziala isset jak caly czas jest null?
			
			if (  (!isset($this->tab->kwota) || !isset($this->tab->oprocentowanie) || !isset($this->tab->czas)) ) return false;  //po co to jest!
		
			if($this->tab->kwota =="")   getMessages()->addError("Nie podano kwoty!");
			if($this->tab->oprocentowanie =="")   getMessages()->addError("Nie podano wartości oprocentowania!");
			
                        if(getMessages()->isGood())
                        {
                            if( !is_numeric($this->tab->kwota))   getMessages()->addError("Podana kwota nie jest liczbą!");
			if( !is_numeric($this->tab->oprocentowanie)) getMessages()->addError("Podane oprocentowanie nie jest liczbą!");
                        return true;
                            
                        } return getMessages()->isGood();
                }
                
                
                
                
                
                
               
			
			
                        
                   
                        
                        
                        public function equals()
			{
                            
                            $this->getParams();
                            
                            if($this->validate())
                            {
                    
				getMessages()->addInfo("Obliczam...");
				$this->result->result= $this->tab->kwota/$this->tab->czas + $this->tab->kwota/$this->tab->czas*$this->tab->oprocentowanie/100;
                                $this->result->result = round($this->result->result,2);
                                
                                getMessages()->addInfo('Wykonano obliczenia.');
                            }
                            $this->generateView();
			}
			
			
			
					
		
                        
                        
              
public function       generateView(){
                //nie trzeba już tworzyć Smarty i przekazywać mu konfiguracji i messages
		// - wszystko załatwia funkcja getSmarty()
    

		getSmarty()->assign('page_title','Przykład 05');
		getSmarty()->assign('page_description','Obiektowość. Funkcjonalność aplikacji zamknięta w metodach różnych obiektów. Pełen model MVC.');
		getSmarty()->assign('page_header','Obiekty w PHP');
				
		
		getSmarty()->assign('tab',$this->tab);
		getSmarty()->assign('result',$this->result);
		
		getSmarty()->display('Cal_view.html');  // już nie podajemy pełnej ścieżki - foldery widoków są zdefiniowane przy ładowaniu Smarty
	}


    

}

