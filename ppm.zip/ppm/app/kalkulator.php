
<?php
require_once dirname(__FILE__).'/../config.php';


//kontroler

require_once _ROOT_PATH.'/lib/Smarty.class.php';

//gdy jeszcze nie podalismy liczby nie wyswietla sie nic, gdy 
//podamy wyswietla sie ciągle liczba nawet po podaniu wyniku, dlatego tak

function getParams(&$form){
	$form['kwota']= isset($_REQUEST['kwota']) ? $_REQUEST['kwota'] : null;
	$form['oprocentowanie'] = isset($_REQUEST['oprocentowanie']) ? $_REQUEST['oprocentowanie'] : null;
	$form['czas']= isset($_REQUEST['czas']) ? $_REQUEST['czas'] : 24;
}



function validate(&$form,&$messages,&$infos,&$hide_intro){
	// jeżeli parametry zostaly poprawnie podane to zwraca falsz i idziemy dalej
	//chodzi o podanie parametrow przed wyswietleniem okna gdzie sie wpisuje dlatego !
	// dzieki request to chyba nie jest do konca potrzebne
	
	if ( ! (isset($form['kwota']) && isset($form['oprocentowanie']) && isset($form['czas'])) ) return false;


$hide_intro = true;



	// typowa walidacja
	if ($form['kwota'] == "") {
		$messages [] = 'Nie podano kwoty kredytu!';
	}
	if ($form['oprocentowanie'] == "") {
		$messages [] = 'Nie podano wysokości oprocentowania!';
	}

	//gdy nie podamy parametrów to juz koniec sprawdzania
	if (count ( $messages ) != 0) 
		return false;
	
	// sprawdzenie, czy wpisane dane są na pewno liczbami a nie literami...
	if (! is_numeric( $form['kwota'] )) {
		$messages [] = 'Podana wartość w kwocie kredytu nie jest liczbą!';
	}
	
	if (! is_numeric( $form['oprocentowanie'] )) {
		$messages [] = 'Podana wartość w wysokości oprocentowania nie jest liczbą!';
	}	
	
	if (count ( $messages ) != 0) 
		return false;
	else {
		$infos [] = 'Przekazano parametry.';
	return true;	
	}
		
	
}

function obliczenia(&$form,&$infos){	
$infos [] = 'Parametry poprawne. Wykonuję obliczenia.';
	$form['rata'] = $form['kwota']/$form['czas'] + $form['kwota']/$form['czas']*$form['oprocentowanie']/100;
$form['rata'] = round($form['rata'],2);
	
	
}



//definicja zmiennych kontrolera
//$form['rata'] = null;            
$messages = array();
$infos = array();
$hide_intro = false;
$form=null;

//pobierz parametry i wykonaj zadanie jeśli wszystko w porządku
getParams($form);
if ( validate($form,$messages,$infos,$hide_intro) ) { // gdy brak błędów
	obliczenia($form,$infos);
}





// 4. Przygotowanie danych dla szablonu

$smarty = new Smarty();

$smarty->assign('app_url',_APP_URL);
$smarty->assign('root_path',_ROOT_PATH);
$smarty->assign('page_title','Przykład 04');
$smarty->assign('page_description','Profesjonalne szablonowanie oparte na bibliotece Smarty');
$smarty->assign('page_header','Szablony Smarty');

$smarty->assign('hide_intro',$hide_intro);

//pozostałe zmienne niekoniecznie muszą istnieć, dlatego sprawdzamy aby nie otrzymać ostrzeżenia
$smarty->assign('form',$form);
//$smarty->assign('result',$rata);
$smarty->assign('messages',$messages);
$smarty->assign('infos',$infos);

// 5. Wywołanie szablonu
$smarty->display(_ROOT_PATH.'/app/kalkulator_widok.html');
