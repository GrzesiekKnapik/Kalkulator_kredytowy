<?php
/* Smarty version 4.1.0, created on 2022-03-29 00:07:55
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Obiektowosc\app\kalkulator_widok.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_624231bb319de0_80323972',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd969967a4f83bdf81a479817842f51e11524c7b' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Obiektowosc\\app\\kalkulator_widok.html',
      1 => 1648505017,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624231bb319de0_80323972 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1917682710624231bb2e2d73_81265262', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1268395282624231bb2e5269_38423852', 'content');
?>




<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../templates/main.html");
}
/* {block 'footer'} */
class Block_1917682710624231bb2e2d73_81265262 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_1917682710624231bb2e2d73_81265262',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Stopka!<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_1268395282624231bb2e5269_38423852 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1268395282624231bb2e5269_38423852',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="ogolny">

<h3>Prosty kalkulator</h2>

<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/app/kalkulator.php" method="post">
	<fieldset>
	<!--kwota to nasza zmienna-->

<label for="kwota">Kwota kredytu</label>	
	<input id="kwota" type="text" placeholder="kwota" name ="kwota" 
	value="<?php echo $_smarty_tpl->tpl_vars['form']->value->kwota;?>
" />PLN
	
	
	<!--value jest potrzebne do zapisania -->
	
	
	<label for="czas">Okres spłaty</label>
	<input id="czas" type="range" min="3" max="48" name="czas" 
	value="<?php echo $_smarty_tpl->tpl_vars['form']->value->czas;?>
";
    oninput="nextElementSibling.value = value"/>
	<output><?php echo $_smarty_tpl->tpl_vars['form']->value->czas;?>
</output> miesiące
		
	
	
	
	<label for="oprocentowanie">Wysokość oprocentownia</label>
	<input id="oprocentowanie" type="text" placeholder="oprocentowanie" name ="oprocentowanie" 
	value="<?php echo $_smarty_tpl->tpl_vars['form']->value->oprocentowanie;?>
"/>%
	

	<input type="submit" value="Oblicz" class="pure-button-primary"/> 
		</fieldset>
	</form>


<div class="messages">


<?php if ($_smarty_tpl->tpl_vars['messages']->value->isError()) {?>
	<h4>Wystąpiły błędy: </h4>
	<ol class="errr">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value->getErrors(), 'errr');
$_smarty_tpl->tpl_vars['errr']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['errr']->value) {
$_smarty_tpl->tpl_vars['errr']->do_else = false;
?>
	<li><?php echo $_smarty_tpl->tpl_vars['errr']->value;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ol>
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['messages']->value->isInfo()) {?>
	<h4>Informacje: </h4>
	<ol class="inf">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value->getInfos(), 'inf');
$_smarty_tpl->tpl_vars['inf']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['inf']->value) {
$_smarty_tpl->tpl_vars['inf']->do_else = false;
?>
	<li><?php echo $_smarty_tpl->tpl_vars['inf']->value;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ol>
<?php }?>

<?php if ((isset($_smarty_tpl->tpl_vars['form']->value['rata']->rata))) {?>
	<h4>Wynik</h4>
	<p class="res">
	<?php echo $_smarty_tpl->tpl_vars['form']->value['rata']->rata;?>

	</p>
<?php }?>




</div>
</div>
<?php
}
}
/* {/block 'content'} */
}
