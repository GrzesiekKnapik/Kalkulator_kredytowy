<?php
class CalcResult {
	
	public $result;	
} 