<?php
/* Smarty version 4.1.0, created on 2022-04-02 20:01:52
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_Powtórki\app\Cal_view.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62488f90a5ad47_89434877',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d657679183363b04a295bc8dc7a38ac22983ce8' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_Powtórki\\app\\Cal_view.html',
      1 => 1648922498,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62488f90a5ad47_89434877 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_29096916262488f90a35c63_21026035', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_153849418062488f90a37348_04155136', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../templates/main.html");
}
/* {block 'footer'} */
class Block_29096916262488f90a35c63_21026035 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_29096916262488f90a35c63_21026035',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Stopka!<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_153849418062488f90a37348_04155136 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_153849418062488f90a37348_04155136',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<div class="ogólny">	
	
	<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/app/Cal.php" method="get">
<fieldset>
		<label for="kwota">Podaj kwote:</label>
		<input type="text" placeholder="kwota PLN" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value['kwota'];?>
"  name ="kwota"/>
		
		<label for="czas">Podaj czas:</label>
		<input type="range"  min="3" max="48" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value['czas'];?>
" name="czas"
		oninput="nextElementSibling.value = value"/>
		<output><?php echo $_smarty_tpl->tpl_vars['tab']->value['czas'];?>
</output> miesiące
		
		<label for="oprocentowanie">Podaj oprocentowanie:</label>
		<input type="text"  placeholder="oprocentowanie %" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value['oprocentowanie'];?>
" name="oprocentowanie"/>
		
		
		
		
		
		<input type="submit"  value="Oblicz" class="pure-button-primary"/>
</fieldset>		
	
	</form>
	
<div  class="messages">
		
		
		<?php if ((isset($_smarty_tpl->tpl_vars['messages']->value))) {?>
	<?php if (count($_smarty_tpl->tpl_vars['messages']->value) > 0) {?> 
		<h4>Wystąpiły błędy: </h4>
		<ol class="err">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value, 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
		<br />
	<?php }
}?>


<?php if ((isset($_smarty_tpl->tpl_vars['infos']->value))) {?>
	<?php if (count($_smarty_tpl->tpl_vars['infos']->value) > 0) {?> 
		<h4>Informacje: </h4>
		<ol class="inf">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['infos']->value, 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((isset($_smarty_tpl->tpl_vars['result']->value))) {?>
	<h4>Wynik:</h4>
	<p class="res">
	Miesięczna rata:&emsp;<?php echo $_smarty_tpl->tpl_vars['result']->value;?>
 PLN
	</p>
	<br />
<?php }?>

</div>
</div>
	
	
<?php
}
}
/* {/block 'content'} */
}
