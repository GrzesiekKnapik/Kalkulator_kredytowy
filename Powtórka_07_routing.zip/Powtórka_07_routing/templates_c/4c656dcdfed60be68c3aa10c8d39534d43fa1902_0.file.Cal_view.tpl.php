<?php
/* Smarty version 4.1.0, created on 2022-04-10 22:41:35
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_07_role\app\views\Cal_view.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_625340ff8b0d84_63859127',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4c656dcdfed60be68c3aa10c8d39534d43fa1902' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_07_role\\app\\views\\Cal_view.tpl',
      1 => 1649608408,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_625340ff8b0d84_63859127 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

 <!--to nam przekazuje nasz css i pure css. Po co to cat!--> <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_22496202625340ff896a83_23868225', 'footer');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_715901097625340ff8980b5_86523728', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'footer'} */
class Block_22496202625340ff896a83_23868225 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_22496202625340ff896a83_23868225',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
przykładowa tresć stopki wpisana do szablonu głównego z szablonu kalkulatora<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_715901097625340ff8980b5_86523728 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_715901097625340ff8980b5_86523728',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>





<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout"  class="pure-menu-heading pure-menu-link">wyloguj</a>
	<span style="float:right;">użytkownik: <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
, rola: <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>
</span>
</div>

<div class="ogólny">	
	
    <form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
calcCompute" method="post">
<fieldset>
		<label for="kwota">Podaj kwote:</label>
                <input type="text" placeholder="kwota PLN" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->kwota;?>
"  name ="kwota"/>
		
		<label for="czas">Podaj czas:</label>
                <input type="range"  min="3" max="48" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->czas;?>
" name="czas"
		oninput="nextElementSibling.value = value"/>
		<output><?php echo $_smarty_tpl->tpl_vars['tab']->value->czas;?>
</output> miesiące
		
		<label for="oprocentowanie">Podaj oprocentowanie:</label>
                <input type="text"  placeholder="oprocentowanie %" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->oprocentowanie;?>
" name="oprocentowanie"/>
		
		
		
		
		
		<input type="submit"  value="Oblicz" class="pure-button-primary"/>
</fieldset>		
	
	</form>
	

		
	
<?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    


<?php if ((isset($_smarty_tpl->tpl_vars['result']->value->result))) {?>
	<h4>Wynik:</h4>
	<p class="res">
	Miesięczna rata:&emsp;<?php echo $_smarty_tpl->tpl_vars['result']->value->result;?>
 PLN

	</p>
	<br />
<?php }?>



</div>
	
	
<?php
}
}
/* {/block 'content'} */
}
