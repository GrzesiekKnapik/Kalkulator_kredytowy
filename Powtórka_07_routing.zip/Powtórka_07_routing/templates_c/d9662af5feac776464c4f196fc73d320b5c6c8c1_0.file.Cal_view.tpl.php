<?php
/* Smarty version 4.1.0, created on 2022-04-05 20:17:51
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_6b_namespaces\app\views\Cal_view.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_624c87cfc03f79_57904078',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd9662af5feac776464c4f196fc73d320b5c6c8c1' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_6b_namespaces\\app\\views\\Cal_view.tpl',
      1 => 1649182317,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624c87cfc03f79_57904078 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

 <!--to nam przekazuje nasz css i pure css. Po co to cat!--> <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1145640647624c87cfbe0194_60014639', 'footer');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_229794223624c87cfbe1a08_75226118', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'footer'} */
class Block_1145640647624c87cfbe0194_60014639 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_1145640647624c87cfbe0194_60014639',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
przykładowa tresć stopki wpisana do szablonu głównego z szablonu kalkulatora<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_229794223624c87cfbe1a08_75226118 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_229794223624c87cfbe1a08_75226118',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>







<div class="ogólny">	
	
    <form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
calcCompute" method="post">
<fieldset>
		<label for="kwota">Podaj kwote:</label>
                <input type="text" placeholder="kwota PLN" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->kwota;?>
"  name ="kwota"/>
		
		<label for="czas">Podaj czas:</label>
                <input type="range"  min="3" max="48" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->czas;?>
" name="czas"
		oninput="nextElementSibling.value = value"/>
		<output><?php echo $_smarty_tpl->tpl_vars['tab']->value->czas;?>
</output> miesiące
		
		<label for="oprocentowanie">Podaj oprocentowanie:</label>
                <input type="text"  placeholder="oprocentowanie %" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->oprocentowanie;?>
" name="oprocentowanie"/>
		
		
		
		
		
		<input type="submit"  value="Oblicz" class="pure-button-primary"/>
</fieldset>		
	
	</form>
	
<div  class="messages">
		
		
<?php if ($_smarty_tpl->tpl_vars['messages']->value->isError()) {?>
		<h4>Wystąpiły błędy: </h4>
		<ol class="err">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value->getErrors(), 'err');
$_smarty_tpl->tpl_vars['err']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['err']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
		<br />
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['messages']->value->isInfo()) {?>	
		<h4>Informacje: </h4>
		<ol class="inf">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value->getInfos(), 'inf');
$_smarty_tpl->tpl_vars['inf']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['inf']->value) {
$_smarty_tpl->tpl_vars['inf']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['inf']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
<?php }?>


<?php if ((isset($_smarty_tpl->tpl_vars['result']->value->result))) {?>
	<h4>Wynik:</h4>
	<p class="res">
	Miesięczna rata:&emsp;<?php echo $_smarty_tpl->tpl_vars['result']->value->result;?>
 PLN

	</p>
	<br />
<?php }?>

</div>
</div>
	
	
<?php
}
}
/* {/block 'content'} */
}
