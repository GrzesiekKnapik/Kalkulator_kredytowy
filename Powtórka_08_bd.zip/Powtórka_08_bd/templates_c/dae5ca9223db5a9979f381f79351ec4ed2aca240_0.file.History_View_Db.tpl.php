<?php
/* Smarty version 4.1.0, created on 2022-04-25 23:56:45
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_07_routing\app\views\History_View_Db.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6267191d6c0868_22600232',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dae5ca9223db5a9979f381f79351ec4ed2aca240' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_07_routing\\app\\views\\History_View_Db.tpl',
      1 => 1650923802,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:records_Db_View.tpl' => 1,
  ),
),false)) {
function content_6267191d6c0868_22600232 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16265840906267191d6b09a0_37266434', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_16265840906267191d6b09a0_37266434 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_16265840906267191d6b09a0_37266434',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="pure-menu pure-menu-horizontal bottom-margin">
  <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
        
  <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
calcCompute" class="pure-menu-heading pure-menu-link">Powrót do kalkulatora</a>
</div>        



       
        <h1> Historia: </h1>
                <?php $_smarty_tpl->_subTemplateRender('file:records_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
             
<?php
}
}
/* {/block 'content'} */
}
