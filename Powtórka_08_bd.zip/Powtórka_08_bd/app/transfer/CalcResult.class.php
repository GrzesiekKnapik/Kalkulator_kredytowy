<?php

namespace app\transfer;
//tutaj bedzie zapisany wynik

class CalcResult{
    
    public $result;
}

