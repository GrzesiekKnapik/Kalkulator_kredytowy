
<?php
require_once dirname(__FILE__).'/../config.php';


//kontroler

include _ROOT_PATH.'/app/security/check.php';

function getParams(&$kwota,&$oprocentowanie,&$czas){
	$kwota= isset($_REQUEST['kwota']) ? $_REQUEST['kwota'] : null;
	$oprocentowanie = isset($_REQUEST['oprocentowanie']) ? $_REQUEST['oprocentowanie'] : null;
	$czas= isset($_REQUEST['czas']) ? $_REQUEST['czas'] : null;
}


/*
$kwota = $_REQUEST["kwota"];
$oprocentowanie = ($_REQUEST["oprocentowanie"]);
$czas = $_REQUEST["czas"];

if ($kwota == "" || $oprocentowanie==""){
	$messages = 1;
}else if($kwota == "0" || $oprocentowanie=="0"){
	$messages = 2;

}else 
{
$rata = $kwota/$czas + $kwota/$czas*$oprocentowanie/100;
$rata = round($rata,2);
}
*/

function validate(&$kwota,&$oprocentowanie,&$czas,&$messages){
	// sprawdzenie, czy parametry zostały przekazane
	if ( ! (isset($kwota) && isset($oprocentowanie) && isset($czas))) {
		// sytuacja wystąpi kiedy np. kontroler zostanie wywołany bezpośrednio - nie z formularza
		// teraz zakładamy, ze nie jest to błąd. Po prostu nie wykonamy obliczeń
		return false;
	}

	// sprawdzenie, czy potrzebne wartości zostały przekazane
	if ( $kwota == "") {
		$messages [] = 'Nie podano liczby 1';
	}
	if ( $oprocentowanie == "") {
		$messages [] = 'Nie podano liczby 2';
	}

	//nie ma sensu walidować dalej gdy brak parametrów
	if (count ( $messages ) != 0) return false;
	
	// sprawdzenie, czy $x i $y są liczbami całkowitymi
	if (! is_numeric( $kwota )) {
		$messages [] = 'Pierwsza wartość nie jest liczbą całkowitą';
	}
	
	if (! is_numeric( $oprocentowanie )) {
		$messages [] = 'Druga wartość nie jest liczbą całkowitą';
	}	

	if (count ( $messages ) != 0) return false;
	else return true;
}

function process(&$kwota,&$oprocentowanie,&$czas,&$messages,&$rata){
	
	$rata = $kwota/$czas + $kwota/$czas*$oprocentowanie/100;
$rata = round($rata,2);
	
	
}



//definicja zmiennych kontrolera
$kwota = null;
$oprocentowanie = null;
$czas = null;
$rata = null;
$messages = array();

//pobierz parametry i wykonaj zadanie jeśli wszystko w porządku
getParams($kwota,$oprocentowanie,$czas);
if ( validate($kwota,$oprocentowanie,$czas,$messages) ) { // gdy brak błędów
	process($kwota,$oprocentowanie,$czas,$messages,$rata);
}





include 'kalkulator_widok.php';
