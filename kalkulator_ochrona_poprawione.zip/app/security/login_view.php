<!DOCTYPE HTML>
<html lang = "pl">
<head>
	<title>Logowanie</title>
	<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
</head>
<body>

<body>
<!--odpowiada tylko za tlo musi byc sam background inaczej by trzeba tworzyc klase z klikiem htm-->
<div style="background: url(rr.jpg);position:absolute;height:100%; width:100%">
</body>


<div style="width:10%; margin: 15em auto;">

<form action="<?php print(_APP_ROOT); ?>/app/security/login.php" method="post" class="pure-form pure-form-stacked">
	<legend>Logowanie</legend>
	<fieldset>
		<label>login: </label>
		<input type="text" name="login" value="<?php out($form['login']); ?>" />
		<label>hasło: </label>
		<input type="password" name="haslo" />
	</fieldset>
	<input type="submit" value="zaloguj" class="pure-button pure-button-primary"/>
</form>	

<?php

if (isset($messages)) {
	if (count ( $messages ) > 0) {
		echo '<ol style="margin-left: auto;margin-right:auto;margin-top: 1em; padding: 1em 1em 1em 2em; border-radius: 1em; background-color: #f88; width:25em;">';
		foreach ( $messages as $key => $msg ) {
			echo '<li>'.$msg.'</li>';
		}
		echo '</ol>';
	}
}
?>

</div>

</body>
</html>