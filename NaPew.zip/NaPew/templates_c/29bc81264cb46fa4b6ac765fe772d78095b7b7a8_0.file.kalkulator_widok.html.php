<?php
/* Smarty version 4.1.0, created on 2022-03-28 21:29:36
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\NaPew\app\kalkulator_widok.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62420ca0d89924_33142746',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '29bc81264cb46fa4b6ac765fe772d78095b7b7a8' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\NaPew\\app\\kalkulator_widok.html',
      1 => 1648495664,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62420ca0d89924_33142746 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_50407205762420ca0d632e8_37532435', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11383259962420ca0d653c4_31245273', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../templates/main.html");
}
/* {block 'footer'} */
class Block_50407205762420ca0d632e8_37532435 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_50407205762420ca0d632e8_37532435',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Stopka!<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_11383259962420ca0d653c4_31245273 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_11383259962420ca0d653c4_31245273',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="ogolny">

<h3>Prosty kalkulator</h2>

<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/app/kalkulator.php" method="post">
	<fieldset>
	<!--kwota to nasza zmienna-->

<label for="kwota">Kwota kredytu</label>	
	<input id="kwota" type="text" placeholder="kwota" name ="kwota" 
	value="<?php echo $_smarty_tpl->tpl_vars['form']->value['kwota'];?>
" />PLN
	
	
	<!--value jest potrzebne do zapisania -->
	
	
	<label for="czas">Okres spłaty</label>
	<input id="czas" type="range" min="3" max="48" name="czas" 
	value="<?php echo $_smarty_tpl->tpl_vars['form']->value['czas'];?>
";
    oninput="nextElementSibling.value = value"/>
	<output><?php echo $_smarty_tpl->tpl_vars['form']->value['czas'];?>
</output> miesiące
		
	
	
	
	<label for="oprocentowanie">Wysokość oprocentownia</label>
	<input id="oprocentowanie" type="text" placeholder="oprocentowanie" name ="oprocentowanie" 
	value="<?php echo $_smarty_tpl->tpl_vars['form']->value['oprocentowanie'];?>
" />%
	

	<input type="submit" value="Oblicz" class="pure-button"/> 
		</fieldset>
	</form>


<div class="messages">

<?php if ((isset($_smarty_tpl->tpl_vars['messages']->value))) {?>
	<?php if (count($_smarty_tpl->tpl_vars['messages']->value) > 0) {?> 
		<h4>Wystąpiły błędy: </h4>
		<ol class="errr">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value, 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((isset($_smarty_tpl->tpl_vars['infos']->value))) {?>
	<?php if (count($_smarty_tpl->tpl_vars['infos']->value) > 0) {?> 
		<h4>Informacje: </h4>
		<ol class="inf">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['infos']->value, 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((isset($_smarty_tpl->tpl_vars['form']->value['rata']))) {?>
	<h4>Wynik:</h4>
	<p class="res">
	<?php echo $_smarty_tpl->tpl_vars['form']->value['rata'];?>

	</p>
<?php }?>


</div>
</div>
<?php
}
}
/* {/block 'content'} */
}
